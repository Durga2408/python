#Program describing list
#written on 06-09-2023
#written by durga
emptylist=[]
print("THe Empty list is:",emptylist)
print("The datatye of emptylist:",type(emptylist))
print("The Size or number of items in the list is:",len(emptylist))
homogenouslist=[1,2,3,34,5,6,6,77,98,45]
print("The homogenouslist List is:",homogenouslist)
print("The Size or number of items in the homogenouslist is:",len(homogenouslist))
print("The datatye of homogenouslist:",type(homogenouslist))
hetrogenouslist=["Names","fruits",9.8,"class",1,True,2,6,7,45,34,2,"Names",False]
print("The hetrogenouslist List is:",hetrogenouslist)
print("The Size or number of items in the hetrogenouslist is:",len(hetrogenouslist))
print(hetrogenouslist[3:6])
print(list(hetrogenouslist))
list=[1,2,7,False,8,"jay","raju",5,True]
count=0
for item in list[::-1]:
    count+=1
    print("The item:",count,item)
myList=["raju",43,89,"vani",["babu",2,3,8,],43,"how",56,2]
print(myList.count(43))
print(myList.pop())